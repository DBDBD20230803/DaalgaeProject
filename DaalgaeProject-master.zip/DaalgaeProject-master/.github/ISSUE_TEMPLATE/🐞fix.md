---
name: "\U0001F41EFIX"
about: 에러 사항 및 상황 설명
title: "[Fix]"
labels: bug
assignees: ''

---

## 설명

## 스크린샷
