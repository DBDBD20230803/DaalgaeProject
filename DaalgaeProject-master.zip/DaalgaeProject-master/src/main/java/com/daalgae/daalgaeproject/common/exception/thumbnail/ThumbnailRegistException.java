package com.daalgae.daalgaeproject.common.exception.thumbnail;

public class ThumbnailRegistException extends Exception {

    public ThumbnailRegistException() {}

    public ThumbnailRegistException(String msg) {
        super(msg);
    }
}
