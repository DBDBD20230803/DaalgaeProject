package com.daalgae.daalgaeproject.common.exception.board;

public class BoardDeleteException extends Exception {

    public BoardDeleteException() {}

    public BoardDeleteException(String msg) {
        super(msg);
    }
}
