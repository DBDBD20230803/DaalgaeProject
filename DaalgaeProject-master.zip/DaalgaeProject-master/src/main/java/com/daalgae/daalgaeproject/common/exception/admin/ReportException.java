package com.daalgae.daalgaeproject.common.exception.admin;

public class ReportException extends Exception{
        public ReportException() {}
        public ReportException(String msg) {
            super(msg);
        }
    }

