package com.daalgae.daalgaeproject.mainConnect.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class AllSearchCriteria {
    private String postType;
    private String keyword;
}
