package com.daalgae.daalgaeproject.common.exception.board;

public class BoardRegistException extends Exception {

    public BoardRegistException() {}

    public BoardRegistException(String msg) {
        super(msg);
    }
}
