package com.daalgae.daalgaeproject.exception.member;

public class MemberRegistException extends Exception{

    public MemberRegistException(){}

    public MemberRegistException(String msg){ super(msg); }
}
