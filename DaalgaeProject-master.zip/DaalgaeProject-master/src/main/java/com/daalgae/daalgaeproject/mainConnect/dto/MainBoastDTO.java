package com.daalgae.daalgaeproject.mainConnect.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@ToString
public class MainBoastDTO {
    private String post_code;
    private String post_title;
    private String attach_thumb_addr;
}
