package com.daalgae.daalgaeproject.common.exception.board;

public class BoardUpdateException extends Exception {

    public BoardUpdateException() {}

    public BoardUpdateException(String msg) {
        super(msg);
    }
}
