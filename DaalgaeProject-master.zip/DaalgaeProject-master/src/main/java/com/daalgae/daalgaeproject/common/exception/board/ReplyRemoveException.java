package com.daalgae.daalgaeproject.common.exception.board;

public class ReplyRemoveException extends Exception {

    public ReplyRemoveException() {}

    public ReplyRemoveException(String msg) {
        super(msg);
    }
}
