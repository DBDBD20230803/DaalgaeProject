package com.daalgae.daalgaeproject.common.exception.board;

public class ReplyRegistException extends Exception {

    public ReplyRegistException() {}

    public ReplyRegistException(String msg) {
        super(msg);
    }
}
