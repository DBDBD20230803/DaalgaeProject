package com.daalgae.daalgaeproject.exception.member;

public class EmailAuthException extends Exception{
    public EmailAuthException(){}

    public EmailAuthException(String msg){ super(msg); }
}
