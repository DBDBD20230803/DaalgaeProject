package com.daalgae.daalgaeproject.exception.member;

public class MemberModifyException extends Exception {
    public MemberModifyException(){}

    public MemberModifyException(String msg) {super(msg);}

}
