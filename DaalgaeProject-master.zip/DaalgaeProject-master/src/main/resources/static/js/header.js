$(document).ready( function() {
    $('#headers').css("position", "fixed");
    $('#headers').css("width", "100%");
    $('#headers').css("z-index", "5");
    $('#menu').css("margin-top", "-16px");
});