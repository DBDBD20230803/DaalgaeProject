const qnaList = [
    {
        q: '개의 털이 빠진다면...',
        a: [
            { answer: '장모', type: 'golden'},
            { answer: '단모', type: 'chiwawa'},
        ]
    },
    {
        q: '활동성',
        a: [
            { answer: '활동적이다', type: 'golden'},
            { answer: '집순이다', type: 'shihtzu'},
        ]
    },
    {
        q: '주거환경',
        a: [
            { answer: '단독/전원주택', type: 'jindo'},
            { answer: '아파트/연립주택', type: 'poodle'},
        ]
    },
    {
        q: '가족이 집을 비우는 경우는...',
        a: [
            { answer: '집에 항상 사람이 있다.', type: 'mix'},
            { answer: '때때로 반려견이 혼자 있는다.', type: 'poodle'},
        ]
    },
    {
        q: '나는 1인 가구인가...?',
        a: [
            { answer: '예', type: 'shihtzu'},
            { answer: ' 아니오', type: 'maltese'},
        ]
    },
    {
        q: '반려견 양육 경험이 있는가...?',
        a: [
            { answer: '예', type: 'jindo'},
            { answer: '아니오', type: 'shihtzu'},
        ]
    },
    {
        q: '병원비를 감당할 여유가 있는지?',
        a: [
            { answer: '예', type: 'hursky'},
            { answer: '아니오', type: 'mix'},
        ]
    },
    {
        q: '대형견 VS 소형견',
        a: [
            { answer: '작고 소중한 소형견', type: 'golden'},
            { answer: '늠름한 대형견', type: 'maltese'},
        ]
    }
]